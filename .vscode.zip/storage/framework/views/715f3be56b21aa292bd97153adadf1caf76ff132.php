

<?php $__env->startSection('content'); ?>
<div class="page-content">

    
    
    <div class="card">
        <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">Show All job</h4>

            <div class="flex-shrink-0">
                <div class="form-check form-switch form-switch-right form-switch-md">
                    <a href="<?php echo e(route('admin.job.create')); ?>" class="btn btn-success btn-icon waves-effect waves-light"><i class="ri-check-double-line"></i></a>
                </div>
            </div>
            
        </div><!-- end card header -->

        <div class="card-body">
            <div class="live-preview">
                <div class="table-responsive">
                    
                    <table class="table table-borderless align-middle table-nowrap mb-0 display"id="data-table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">CV</th>
                                <th scope="col">Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-medium"><?php echo e($key +1); ?></td>
                                <td><?php echo e($job->name); ?></td>
                                <td><?php echo e($job->email); ?></td>
                                <td><a href="<?php echo asset($job->cv); ?>" download><i class=" ri-file-fill"></i></a></td>

                                
                                <td><?php echo e($job->created_at->format('d/m/Y')); ?></td>
                                
                                <td>
                                    <div class="hstack gap-3 fs-15">
                                        
                                        <a onclick="deleteId(<?php echo e($job->id); ?>)" class="link-danger"><i class="ri-delete-bin-5-line"></i></a>

                                        <form action="<?php echo e(route('admin.job.destroy',$job->id)); ?>" id="delete_form<?php echo e($job->id); ?>" method="post" style="display: none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div><!-- end card-body -->
    </div><!-- end card -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WWW\NFT-Constructer\resources\views/job/index.blade.php ENDPATH**/ ?>