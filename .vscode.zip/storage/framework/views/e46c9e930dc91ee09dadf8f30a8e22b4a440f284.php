<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="col-xxl-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Update Portfolio</h4>
               
            </div><!-- end card header -->

            <div class="card-body">
                <div class="live-preview">
                    <form action="<?php echo e(route('admin.portfolio.update', $portfolio->id)); ?>" method="POST" class="row g-3" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="col-md-12">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control"name="name" value="<?php echo e($portfolio->name); ?>" id="name" placeholder="Name">
                        </div>
                        <div class="col-md-12">
                            <label for="link" class="form-label">Link</label>
                            <input type="text" class="form-control"value=<?php echo e($portfolio->link); ?> name="link" id="link" placeholder="Link">
                        </div>
                        <div class="mb-3">
                            <label for="description" class="form-label"> Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" placeholder="Description"><?php echo e($portfolio->description); ?></textarea>
                        </div>

                        <div class="col-md-12">
                            <img src="<?php echo e(asset($portfolio->image)); ?>" alt="" style="width:200px">

                        </div>
                        <div class="col-md-12">
                            <label for="image" class="form-label">New Image</label>
                            <input type="file" class="form-control" name="image" id="image">
                        </div>

                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update Portfolio</button>
                            </div>
                        </div>
                        
                    </form>
                </div>
             
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WWW\NFT-Constructer\resources\views/portfolio/update.blade.php ENDPATH**/ ?>