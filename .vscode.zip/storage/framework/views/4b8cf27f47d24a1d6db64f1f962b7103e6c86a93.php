<?php $__env->startSection('content'); ?>
<div class="page-content">

    
    
    <div class="card">
        <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">Show All Latest Contract</h4>
            
        </div><!-- end card header -->

        <div class="card-body">
            <div class="live-preview">
                <div class="table-responsive">
                    
                    <table class="table table-borderless align-middle table-nowrap mb-0 display"id="data-table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Email</th>
                                <th scope="col">Phone</th>
                                <th scope="col">Message</th>
                                <th scope="col">Status</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-medium"><?php echo e($key +1); ?></td>
                                <td><?php echo e($contract->name); ?></td>
                                <td><?php echo e($contract->email); ?></td>
                                <td><?php echo e($contract->phone); ?></td>
                                <td><?php echo e(Str::limit( $contract->message, '10')); ?></td>
                                <td>
                                <?php if($contract->is_read === 1): ?>
                                  <span class="badge badge-soft-success text-uppercase">Seen</span>
                                <?php else: ?>
                                    <span class="badge badge-soft-danger text-uppercase">Un Reed</span>
                                <?php endif; ?>
                                </td>
                                <td>
                                    <div class="hstack gap-3 fs-15">
                                        <a href="<?php echo e(route('admin.contract.show',$contract->id)); ?>" class="link-primary"><i class=" ri-eye-line"></i></a>
                                        <a href="#" onclick="deleteId(<?php echo e($contract->id); ?>)" class="link-danger"><i class="ri-delete-bin-5-line"></i></a>

                                        <form action="<?php echo e(route('admin.contract.destroy',$contract->id)); ?>" id="delete_form<?php echo e($contract->id); ?>" method="post" style="display: none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div><!-- end card-body -->
    </div><!-- end card -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WWW\NFT-Constructer\resources\views/contract/index.blade.php ENDPATH**/ ?>