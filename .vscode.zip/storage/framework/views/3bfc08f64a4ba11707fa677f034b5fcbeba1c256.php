<!-- End Page-content -->

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>document.write(new Date().getFullYear())</script> © Velzon.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design by <a href="https://www.nftconstructer.com/" class="text-muted" target="_blank">NFT CONSTRUCTER</a>.
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\WWW\NFT-Constructer\resources\views/layouts/backend/footer.blade.php ENDPATH**/ ?>