

<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="col-xxl-12">
        <div class="card">
            <div class="card-header align-items-center d-flex">
                <h4 class="card-title mb-0 flex-grow-1">Create Post</h4>
               
            </div><!-- end card header -->

            <div class="card-body">
                <div class="live-preview">
                    <form action="<?php echo e(route('admin.blog.update', $blog->id)); ?>" method="POST" class="row g-3" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="col-md-12">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" value="<?php echo e($blog->title); ?>" name="title" id="title" placeholder="Title">
                        </div>
                        <div class="col-md-12">
                            <label for="seo_title" class="form-label">SEO Title</label>
                            <input type="text" class="form-control" value="<?php echo e($blog->seo_title); ?>" name="seo_title" id="seo_title" placeholder="SEO Title">
                        </div>
                        <div class="col-md-12">
                            <label for="seo_keywords" class="form-label">Seo Keywords</label>
                            <input type="text" class="form-control" value="<?php echo e($blog->seo_keywords); ?>" name="seo_keywords" id="seo_keywords" placeholder="Seo Keywords">
                        </div>
                        <div class="mb-3">
                            <label for="seo_description" class="form-label">SEO Description</label>
                            <textarea class="form-control" id="seo_description" name="seo_description" rows="3" placeholder="SEO Description"><?php echo e($blog->seo_description); ?></textarea>
                        </div>
                        
                        <div class="col-md-12">
                            <label for="description" class="form-label">Description</label>
                                <textarea name="description" id="editor" cols="30" rows="10">
                                    <?php echo e($blog->description); ?>

                                </textarea>
                        </div>
                        <div class="col-md-12">
                            <div class="old-image">
                                <p>Post Image</p>
                                <img src="<?php echo e($blog->main_image); ?>" alt="" width="300px">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" name="image" id="image">
                        </div>
    
                        <div class="col-md-12">
                            <div class="form-check form-switch form-switch-success mb-3">
                                <input class="form-check-input" type="checkbox" role="switch" name="is_approved" id="SwitchCheck3" value="1" <?php echo e(($blog->is_approved == 1) ? 'checked' : ''); ?>>
                                <label class="form-check-label" for="SwitchCheck3">Approved</label>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="text-end">
                                <button type="submit" class="btn btn-primary">Update Post</button>
                            </div>
                        </div>
                    </form>
                </div>
             
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="https://cdn.ckeditor.com/ckeditor5/34.1.0/classic/ckeditor.js"></script>
<script>
    ClassicEditor
        .create( document.querySelector( '#editor' ),
        {
            ckfinder: {
                uploadUrl: '<?php echo e(route('admin.upload').'?_token='.csrf_token()); ?>'
            }
        } )
        .catch( error => {
            console.error( error );
        } );
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WWW\NFT-Constructer\resources\views/blog/edit.blade.php ENDPATH**/ ?>