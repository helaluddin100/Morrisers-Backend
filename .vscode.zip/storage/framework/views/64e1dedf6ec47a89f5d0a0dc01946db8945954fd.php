

<?php $__env->startSection('content'); ?>
<div class="page-content">

    
    
    <div class="card">
        <div class="card-header align-items-center d-flex">
            <h4 class="card-title mb-0 flex-grow-1">Show All order</h4>            
        </div><!-- end card header -->

        <div class="card-body">
            <div class="live-preview">
                <div class="table-responsive">
                    
                    <table class="table table-borderless align-middle table-nowrap mb-0 display"id="data-table">
                        <thead>
                            <tr>
                                <th scope="col">ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Symbol</th>
                                <th scope="col">Logo</th>
                                <th scope="col">Document</th>
                                <th scope="col">PM Color</th>
                                <th scope="col">SD Color</th>
                                <th scope="col">EX Website</th>
                                <th scope="col">Network</th>
                                <th scope="col">Supply</th>
                                <th scope="col">Freesale</th>
                                <th scope="col">Presale</th>
                                <th scope="col">Whitelist</th>
                                <th scope="col">PS Price</th>
                                <th scope="col">PS Price</th>
                                <th scope="col">Reveal</th>
                                <th scope="col">Date</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="fw-medium"><?php echo e($key +1); ?></td>
                                <td><?php echo e(Str::limit($order->collection_name, '10')); ?></td>
                                <td><?php echo e($order->symbol); ?></td>

                                <td><a href="<?php echo asset($order->logo); ?>" download><img src="<?php echo asset($order->logo); ?>" alt="Image not found" style="max-width: 50px"></a></td>
                                <td>
                                <a href="<?php echo asset($order->content_document); ?>" class="download" download>
                                    <i class=" ri-file-fill"></i>
                                </a>
                                </td>
                                <td><?php echo e($order->primary_color); ?></td>
                                <td><?php echo e($order->secondary_color); ?></td>
                                <td><a href="<?php echo e($order->example_website); ?>" target="_blank"><?php echo e(Str::limit($order->example_website, '15')); ?></a></td>

                                <td><?php echo e($order->network); ?></td>
                                <td><?php echo e($order->total_supply); ?></td>
                                <td><?php echo e($order->want_freesale); ?></td>
                                <td><?php echo e($order->want_presale); ?></td>
                                <td><?php echo e($order->want_whitelist_presale); ?></td>
                                <td><?php echo e($order->presale_price); ?></td>
                                <td><?php echo e($order->publicsale_price); ?></td>
                                <td><?php echo e($order->want_reveal); ?></td>
                                <td><?php echo e($order->created_at->format('d/m/Y')); ?></td>
                                
                                <td>
                                    <div class="hstack gap-3 fs-15">
                                        <a href="<?php echo e(route('admin.order.show',$order->id)); ?>" class="link-primary"><i class=" ri-eye-line"></i></a>
                                        <!-- <a href="<?php echo e(route('admin.order.edit',$order->id)); ?>" class="link-primary"><i class=" ri-edit-box-line"></i></a> -->
                                        <a onclick="deleteId(<?php echo e($order->id); ?>)" class="link-danger"><i class="ri-delete-bin-5-line"></i></a>

                                        <form action="<?php echo e(route('admin.order.destroy',$order->id)); ?>" id="delete_form<?php echo e($order->id); ?>" method="post" style="display: none">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div><!-- end card-body -->
    </div><!-- end card -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WWW\NFT-Constructer\resources\views/orders/index.blade.php ENDPATH**/ ?>